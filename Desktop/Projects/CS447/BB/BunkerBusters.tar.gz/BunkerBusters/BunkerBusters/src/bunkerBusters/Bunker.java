package bunkerBusters;

import jig.Entity;
import jig.ResourceManager;

public class Bunker extends Entity {
	
	int playerNumber;
	
	public Bunker(int playerNumber, int x, int y){
		super(x, y);
		switch (playerNumber){
			case 0:
				addImageWithBoundingBox(ResourceManager.getImage(bunkerBusters.BUNKERR_RSC));
			case 1:
				addImageWithBoundingBox(ResourceManager.getImage(bunkerBusters.BUNKERB_RSC));
			case 2:
				addImageWithBoundingBox(ResourceManager.getImage(bunkerBusters.BUNKERR_RSC));
			case 3:
				addImageWithBoundingBox(ResourceManager.getImage(bunkerBusters.BUNKERB_RSC));
			default:
		}

		
	}
	

}
