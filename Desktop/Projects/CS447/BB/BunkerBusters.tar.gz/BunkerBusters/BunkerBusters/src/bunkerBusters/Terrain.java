package bunkerBusters;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.newdawn.slick.Image;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.util.BufferedImageUtil;

import bunkerBusters.bunkerBusters;
import jig.Entity;

	public class Terrain extends Entity{
		BufferedImage drawableImg;
		Image renderableImg;
		int collision = 0;
		
		public Terrain (final float x, final float y) throws IOException {
			super(x, y);
			//addImage(ResourceManager.getImage(BounceGame.PADDLE_PADDLEIMG_RSC));
			drawableImg = ImageIO.read(ClassLoader.getSystemResource(bunkerBusters.TERRAIN1_RSC));					
			Texture tex = BufferedImageUtil.getTexture("dummy", drawableImg); // "dummy", you can use any string here , does not matter
			renderableImg = new Image(tex);		
			addImage(renderableImg);
		}

		public void update(Explosion boom) {
		


		for(int i = (int) boom.getCoarseGrainedMinX(); i <= boom.getCoarseGrainedMaxX(); i++) {
			for (int j = (int) boom.getCoarseGrainedMinY(); j <= boom.getCoarseGrainedMaxY(); j++){
				if (Math.sqrt(Math.pow(i - boom.getX(), 2) + Math.pow(j - boom.getY(), 2)) <= boom.radius-1 && i > 0 && i < drawableImg.getWidth() && j > 0 && j < drawableImg.getHeight()){
				drawableImg.setRGB(i, j, 256); 
				}
			}
		}
		removeImage(renderableImg);
		try {
			Texture tex = BufferedImageUtil.getTexture("dummy", drawableImg);
			renderableImg = new Image(tex);		
			addImage(renderableImg);
		} catch(IOException e) {}
	}	
}
