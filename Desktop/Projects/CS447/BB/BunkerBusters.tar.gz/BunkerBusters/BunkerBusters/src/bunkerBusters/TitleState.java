package bunkerBusters;

import java.util.Iterator;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Point;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

public class TitleState extends BasicGameState {
	Image button;
	Image button2;
	Image title;
	int players = 2;
	int rounds = 1;
	int startingCash = 5000;
	Color myColor = new Color(35, 0 ,180);
	

	public void enter(GameContainer container, StateBasedGame game) {
		//generate terrain
	}

	
	@Override
	public void init(GameContainer container, StateBasedGame game)
			throws SlickException {
		button = new Image(bunkerBusters.BUTTON_RSC);
		button2 = new Image(bunkerBusters.BUTTON2_RSC);
		title = new Image(bunkerBusters.TITLE_RSC);
	}
	
	@Override
	public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException {
		title.draw(220, 50);
		button.draw(200,500);
		button.draw(450,500);
		button.draw(700,500);
		button2.draw(300, 600);
		g.setColor(myColor);
		g.drawString("Players: " + Integer.toString(players), 230,510);
		g.drawString("Rounds: " + Integer.toString(rounds), 480,510);
		g.drawString("Start $: " + Integer.toString(startingCash), 715,510);
		

	}

	@Override
	public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException {
		int posX = container.getInput().getMouseX(); //detects user loading a saved game
		int posY = container.getInput().getMouseY();
		
		if (((posX > 200) && (posX < 200 + 150)) && ((posY > 500) && (posY < 500 + 37))){
			if (container.getInput().isMousePressed(0)){
				if (players < 4)
			players++;
				else players = 2;
			}
		}
		if (((posX > 450) && (posX < 450 + 150)) && ((posY > 500) && (posY < 500 + 37))){
			if (container.getInput().isMousePressed(0)){
				if (rounds < 4)
			rounds++;
				else rounds = 1;
			}
		}
		if (((posX > 700) && (posX < 700 + 150)) && ((posY > 500) && (posY < 500 + 37))){
			if (container.getInput().isMousePressed(0)){
				if (startingCash < 10000)
			startingCash += 1000;
				else startingCash = 0;
			}
		}
		if (((posX > 300) && (posX < 300 + 450)) && ((posY > 600) && (posY < 600 + 3*37))){
			if (container.getInput().isMousePressed(0)){
				((PlayState)game.getState(bunkerBusters.PLAYSTATE)).setPlayers(players);
				game.enterState(bunkerBusters.PLAYSTATE);
			}
		}
	}
	
	@Override
	public int getID() {
		return bunkerBusters.TITLESTATE;
	}
}
