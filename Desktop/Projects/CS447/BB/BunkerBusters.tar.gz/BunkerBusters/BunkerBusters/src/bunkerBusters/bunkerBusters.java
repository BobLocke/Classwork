package bunkerBusters;

import java.io.IOException;
import java.util.ArrayList;

import jig.Entity;
import jig.ResourceManager;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

import bunkerBusters.Explosion;

public class bunkerBusters extends StateBasedGame {
	
	public static final int TITLESTATE = 0;
	public static final int SHOPSTATE = 1;
	public static final int PLAYSTATE = 2;
	public static final int GAMEOVERSTATE = 3;
	
	//public static final String TERRAIN1_RSC = "/media/RYAN DEAN/CS447/git/BunkerBusters/BunkerBusters/src/bunkerBusters/resource/testField.png";
	public static final String TERRAIN1_RSC = "bunkerBusters/resource/testField.png";
	public static final String EXPLOSION_RSC = "bunkerBusters/resource/boom.png";
	public static final String BUNKERR_RSC = "bunkerBusters/resource/bunkerR.png";
	public static final String BUNKERB_RSC = "bunkerBusters/resource/bunkerB.png";
	public static final String BUNKERG_RSC = "bunkerBusters/resource/bunkerG.png";
	public static final String BUNKERY_RSC = "bunkerBusters/resource/bunkerY.png";
	public static final String TITLE_RSC = "bunkerBusters/resource/title.png";
	public static final String BUTTON_RSC = "bunkerBusters/resource/button.png";
	public static final String BUTTON2_RSC = "bunkerBusters/resource/button2.png";

	public final int ScreenWidth; 
	public final int ScreenHeight;
	Terrain terrain;
	Bunker[] bunkers;
	ArrayList<Explosion> explosions;
	Hud hud;
	
	public bunkerBusters(String title, int height, int width) {
		super(title);
		ScreenHeight = height;
		ScreenWidth = width;
		explosions = new ArrayList<Explosion>(100);

		Entity.setCoarseGrainedCollisionBoundary(Entity.AABB);
	}

	
	@Override
	public void initStatesList(GameContainer container) throws SlickException {
		addState(new TitleState());
		addState(new PlayState());
		//addState(new FireState());
		//addState(new ShopState());
		//addState(new GameOverState());
		
		ResourceManager.loadImage(EXPLOSION_RSC);
		ResourceManager.loadImage(BUNKERR_RSC);
		ResourceManager.loadImage(BUNKERB_RSC);
		ResourceManager.loadImage(BUNKERG_RSC);
		ResourceManager.loadImage(BUNKERY_RSC);
		ResourceManager.loadImage(TITLE_RSC);
		ResourceManager.loadImage(BUTTON_RSC);
		ResourceManager.loadImage(BUTTON2_RSC);
		
		try {
			terrain = new Terrain(512, 300);
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		AppGameContainer app;
		try {
			app = new AppGameContainer(new bunkerBusters("BUNKER BUSTERS", 800, 600));
			app.setDisplayMode(1024, 768, false);
			app.setVSync(true);
			app.start();
		} catch (SlickException e) {
			e.printStackTrace();
		}

	}

}
