package bunkerBusters;

import java.util.Iterator;
import java.util.Random;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Point;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

import bunkerBusters.bunkerBusters;

class PlayState extends BasicGameState {
	
	int boomCounter = 0;
	int numplayers;
	Random spawn = new Random();
	
	public void enter(GameContainer container, StateBasedGame game) {
		int varX = 0;
		int varY = 0;
		Color Pcolor = new Color(1,2,3);
		boolean tooclose;
		bunkerBusters bb = (bunkerBusters)game;
		for (int i = 0; i < numplayers; i++){
			tooclose = true;
			while (tooclose){
				varX = spawn.nextInt(bb.terrain.drawableImg.getWidth());
				if (varX < 35) varX += 35;
				if (varX > bb.terrain.drawableImg.getWidth() - 35) varX -= 35;
				varY = spawn.nextInt(bb.terrain.drawableImg.getHeight());
				System.out.println(varX + ", " + varY);
				Pcolor = getColor(bb.terrain.drawableImg.getRGB(varX, varY));
				System.out.println("Pcolor: "+ Pcolor + ", Black: " + Color.black + ", White: " + Color.white);
				if (!Pcolor.equals(Color.black)){
					while((!Pcolor.equals(Color.black))){
						System.out.println("WHITE" + varY);
						varY--;		
						Pcolor = getColor(bb.terrain.drawableImg.getRGB(varX, varY));
					}
				} else if (!Pcolor.equals(Color.white)){
					while((!Pcolor.equals(Color.white))){
						System.out.println("BLACK" + varY);
						varY++;
						Pcolor = getColor(bb.terrain.drawableImg.getRGB(varX, varY));
					}
				}
			System.out.println("Final " + varX + ", " + varY + ": " + Pcolor);
			//bb.bunkers[i] = new Bunker(i, varX, varY);
			}
		}
	}

	//Why the hell are colors returned in some stupid format nothing uses?
	private Color getColor(int why) {
		int red = (why & 0x00ff0000) >> 16;
		int green = (why & 0x0000ff00) >> 8;
		int blue = why & 0x000000ff;
		return new Color(red, blue, green);	
	}


	@Override
	public void init(GameContainer container, StateBasedGame game)
			throws SlickException {
	}
	
	public void setPlayers(int players){
		numplayers = players;	
	}
	
	@Override
	public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException {
		bunkerBusters bb = (bunkerBusters)game;
		Input input = container.getInput();
		
		bb.terrain.render(g);
		g.setColor(Color.white);
		g.drawString((input.getMouseX() + ", " + input.getMouseY()), 0, 30);
		for(Iterator<Explosion> br = bb.explosions.iterator(); br.hasNext();){
			Explosion boom = br.next();
			if(boom.duration()){		
				br.remove();
				bb.terrain.update(boom);
			} else {
				boom.render(g);
			}
		}
		
		
		
	}

	@Override
	public void update(GameContainer container, StateBasedGame game, int delta)
			throws SlickException {
		Input input = container.getInput();
		bunkerBusters bb = (bunkerBusters)game;	
		if (((input.getMouseX() > 0) && (input.getMouseX() < bb.terrain.drawableImg.getWidth())) && ((input.getMouseY() > 0) && (input.getMouseY() < bb.terrain.drawableImg.getHeight())))
			if (input.isMouseButtonDown(Input.MOUSE_LEFT_BUTTON)) {
				Point mousePosition = new Point(input.getMouseX(), input.getMouseY());
				bb.explosions.add(new Explosion(mousePosition, 1));
				boomCounter++;
				
			}


	}
	
	public int getID(){
		return bunkerBusters.PLAYSTATE;
	}

}
