package bunkerBusters;

import org.newdawn.slick.geom.Point;

import bunkerBusters.bunkerBusters;
import jig.Entity;
import jig.ResourceManager;

public class Explosion extends Entity{
	
	int boomtimer = 0;
	int radius;
	
	public Explosion(Point p, int type){
		super(p.getX(), p.getY());
		if (type == 1){
			radius = 25;
		}
		addImageWithBoundingBox(ResourceManager.getImage(bunkerBusters.EXPLOSION_RSC));
		boomtimer = 100;
	}

	public boolean duration(){
		if (boomtimer <= 1){
			return true;
		} else boomtimer--;
		return false;
	}
}
