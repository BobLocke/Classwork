#ifndef _NETWORKH_
#define _NETWORKH_

#include "emulator.h"

void udt_send(int AorB, struct pkt packet);

#endif