#ifndef _APPLICATIONH_
#define _APPLICATIONH_

void data_delivery(int AorB, char datasent[20]);

#endif