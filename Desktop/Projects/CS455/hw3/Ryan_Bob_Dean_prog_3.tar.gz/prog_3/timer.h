/********************** Student-callable ROUTINES ***********************/

void stoptimer(int AorB);
void starttimer(int AorB,float increment);