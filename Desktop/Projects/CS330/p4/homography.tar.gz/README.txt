Ryan "Bob" Dean
lockelocke1620@yahoo.com

Assignment 5: Computing Homography Transformations


This program uses LU Decomposition to determine transformations on an image.


Contained in this archive:

README.txt - This readme
LUdecomp.c - the program
LUdecomp.h - header file
homography.c - does homography stuff

to compile:

gcc -g homography.c -std=c99 -Wall -o homography LUdecomp.c

to test:

./homography < [input file]
