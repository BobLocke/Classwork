Ryan "Bob" Dean
lockelocke1620@yahoo.com

Assignment 4: LU Decomposition


This program estimates the solution of Ax = B for x using LU decomposition.


Contained in this archive:

README.txt - This readme
LUdecomp.c - the program
LUdecomp.h - header file
LUtest.c - tests LUdecomp
Makefile - makefile

to compile and test:

make test
